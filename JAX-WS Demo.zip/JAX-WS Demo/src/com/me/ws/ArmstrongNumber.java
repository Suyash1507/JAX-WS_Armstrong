package com.me.ws;

import javax.jws.WebService;

@WebService(endpointInterface = "com.me.ws.ArmstrongNumberService")
public class ArmstrongNumber{
	
	public boolean isArms(int n)
    {
        int temp = n;
        int p = 0;
        int rem;
        while (temp != 0) {
            rem = temp % 10;
            p += Math.pow(rem,3);
            temp = temp / 10;
        }
        
        if (p == n) {
            return true;
        }
        else {
            return false;
        }
    }

}